export interface LoginFormProps {
    onSubmit: (data: { email: string; password: string }) => void;
    className?: string;
}