import React from 'react'

const SingleOrderPage = () => {
  return (
    <div>
      
    </div>
  )
}

export default SingleOrderPage;
