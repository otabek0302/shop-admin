'use client';

import { useEffect, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { OrderItem, OrderStatus } from '@/interfaces/orders';
import { useOrderStore } from '@/store/order-store';
import { useModalStore } from '@/store/modal-store';
import { toast } from 'sonner';
import { Search, Package } from 'lucide-react';
import { useProductStore } from '@/store/product-store';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Product } from '@/interfaces/products';
import { ProductCard } from './order-product-card';
import { OrderItemCard } from './order-item';
import { Divider } from '@/components/ui/divider';
import { useTranslation } from 'react-i18next';

interface OrderFormData {
  orderItems: OrderItem[];
  total: number;
  status: OrderStatus;
}

const createEmptyOrder = (): OrderFormData => ({
  orderItems: [],
  total: 0,
  status: OrderStatus.PENDING,
});

const OrderModal = () => {
  const { t } = useTranslation();
  const { createOrder, updateOrder, loading, editData, setEditData } = useOrderStore();
  const { products, fetchProducts } = useProductStore();
  const { open, setOpen } = useModalStore();

  const [searchQuery, setSearchQuery] = useState('');
  const [formData, setFormData] = useState<OrderFormData>(createEmptyOrder());

  useEffect(() => {
    if (open) {
      fetchProducts();
    }
  }, [open, fetchProducts]);

  useEffect(() => {
    if (!open) {
      setSearchQuery('');
      setFormData(createEmptyOrder());
    }
  }, [open]);

  useEffect(() => {
    if (editData) {
      setFormData({
        orderItems: editData.orderItems,
        total: editData.total,
        status: editData.status,
      });
    } else {
      setFormData(createEmptyOrder());
    }
  }, [editData]);

  useEffect(() => {
    const total = formData.orderItems.reduce((sum, item) => sum + item.total, 0);
    setFormData((prev) => ({ ...prev, total }));
  }, [formData.orderItems]);

  const filteredProducts = products.filter((product) => product.name.toLowerCase().includes(searchQuery.toLowerCase()));

  const handleAddOrderItem = (product: Product) => {
    setFormData((prev) => {
      const existingItemIndex = prev.orderItems.findIndex((item) => item.productId === product.id);

      if (existingItemIndex !== -1) {
        const newOrderItems = [...prev.orderItems];
        const item = newOrderItems[existingItemIndex];
        item.quantity += 1;
        item.total = item.price * item.quantity;
        return { ...prev, orderItems: newOrderItems };
      }

      const newItem = {
        productId: product.id,
        quantity: 1,
        price: product.price,
        total: product.price,
        product: {
          id: product.id,
          name: product.name,
          price: product.price,
          image: product.image.url || '',
        },
      } as OrderItem;

      return {
        ...prev,
        orderItems: [...prev.orderItems, newItem],
      };
    });
    setSearchQuery('');
  };

  const handleRemoveOrderItem = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      orderItems: prev.orderItems.filter((_, i) => i !== index),
    }));
  };

  const handleUpdateOrderItem = (index: number, field: keyof OrderItem, value: string | number) => {
    setFormData((prev) => {
      const newOrderItems = [...prev.orderItems];
      const item = newOrderItems[index];

      if (field === 'quantity') {
        const newQuantity = typeof value === 'number' ? value : parseInt(value as string);
        if (newQuantity > 0) {
          item.quantity = newQuantity;
          item.total = item.price * item.quantity;
        }
      }

      newOrderItems[index] = item;
      return { ...prev, orderItems: newOrderItems };
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.orderItems?.length) {
      toast.error('Please add at least one item to the order');
      return;
    }

    try {
      const orderData = {
        items: formData.orderItems.map((item) => ({
          productId: item.productId,
          quantity: item.quantity,
          price: item.price,
        })),
        status: formData.status,
      };

      if (editData) {
        await updateOrder(editData.id as string, orderData);
        toast.success(t('messages.success.order.order-updated'));
      } else {
        await createOrder(orderData);
        toast.success(t('messages.success.order.order-created'));
      }
      setOpen(false);
      setEditData(null);
    } catch (err) {
        console.error('[ORDER_MODAL_ERROR]', err);
        toast.error(t('messages.error.order.order-save-failed'));
    }
  };

  const handleOpenChange = (isOpen: boolean) => {
    setOpen(isOpen);
    if (!isOpen) setEditData(null);
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="overflow-hidden p-4 sm:max-w-[786px]">
        <DialogHeader>
          <DialogTitle>
            {editData 
              ? t('components.admin-ui.order.order-modal.edit-title', 'Edit Order')
              : t('components.admin-ui.order.order-modal.create-title', 'Create New Order')}
          </DialogTitle>
          <DialogDescription>
            {editData
              ? t('components.admin-ui.order.order-modal.edit-description', 'Modify the order details below')
              : t('components.admin-ui.order.order-modal.create-description', 'Add products to create a new order')}
          </DialogDescription>
        </DialogHeader>
        <div className="flex h-[70vh] w-full flex-col md:flex-row">
          {/* Left Panel - Product Selection */}
          <div className="flex h-full max-w-1/2 flex-1 flex-col p-4">
            <div className="mb-6 flex items-center justify-between">
              <h3 className="flex items-center gap-2 text-lg font-semibold">
                <Package className="text-primary h-5 w-5" />
                {t('components.admin-ui.order.order-modal.products')}
              </h3>
              <Badge variant="outline" className="px-3 py-1 text-sm">
                {products.length || 0} {t('components.admin-ui.order.order-modal.items')}
              </Badge>
            </div>

            <div className="relative mb-6">
              <Search className="text-muted-foreground absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 transform" />
              <Input placeholder={t('components.admin-ui.order.order-modal.search-products')} value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="bg-background h-11 pl-9" />
            </div>

            <ScrollArea className="h-[calc(100%-8rem)] flex-1">
              <div className="grid grid-cols-1 gap-4 pr-4">
                {filteredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} onClick={() => handleAddOrderItem(product)} />
                ))}
              </div>
            </ScrollArea>
          </div>

          <Divider orientation="vertical" />

          {/* Right Panel - Order Items */}
          <div className="flex h-full max-w-1/2 flex-1 flex-col p-4">
            <div className="mb-6 flex items-center justify-between">
              <h3 className="flex items-center gap-2 text-lg font-semibold">
                <Package className="text-primary h-5 w-5" />
                {t('components.admin-ui.order.order-modal.order-items')}
              </h3>
              <Badge variant="outline" className="px-3 py-1 text-sm">
                {formData.orderItems?.length || 0} {t('components.admin-ui.order.order-modal.items')}
              </Badge>
            </div>

            <ScrollArea className="h-[calc(100%-8rem)] flex-1">
              <div className="space-y-4 pr-4">
                {formData.orderItems?.map((item, index) => {
                  const product = products.find((p) => p.id === item.productId);
                  return <OrderItemCard key={index} item={item} index={index} updateOrderItem={handleUpdateOrderItem} removeOrderItem={handleRemoveOrderItem} availableStock={product?.stock || 0} />;
                })}
              </div>
            </ScrollArea>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t p-4">
          <div className="mb-6 flex items-center justify-end">
            <div className="text-right">
              <div className="text-muted-foreground text-sm">{t('components.admin-ui.order.order-modal.total-amount')}</div>
              <div className="text-primary flex items-center gap-1 text-3xl font-bold">₹{formData.total?.toFixed(2)}</div>
            </div>
          </div>

          <div className="flex justify-end gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setOpen(false);
                setEditData(null);
              }}
              className="h-11 px-6">
              {t('components.admin-ui.order.order-modal.cancel')}
            </Button>
            <Button type="submit" disabled={loading || !formData.orderItems?.length} onClick={handleSubmit} className="h-11 px-6">
              {loading ? t('components.admin-ui.order.order-modal.saving') : editData ? t('components.admin-ui.order.order-modal.edit-order') : t('components.admin-ui.order.order-modal.create-order')}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default OrderModal;
